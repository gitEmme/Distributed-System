package Middleware;

public class CResult {
	private String procedureID=new String();
	private int result=0;
	public String getProcedureID() {
		return procedureID;
	}
	public void setProcedureID(String procedureID) {
		this.procedureID = procedureID;
	}
	public int getResult() {
		return result;
	}
	public void setResult(int result) {
		this.result = result;
	}

}
