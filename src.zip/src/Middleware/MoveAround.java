package Middleware;

public interface MoveAround{
	int moveHorizontal(int integer, String string);
	int moveVertical(int integer, String string);
	}