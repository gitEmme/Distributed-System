package cads.parser.generated;

public class Example4_IDLMoveAround {

   
    public int moveAround(int integer, String string) {
        System.out.println("currently empty methode body!");
        return 0;
    }

    public int moveAround2(int integer, String string) {
        System.out.println("currently empty methode body!");
        return 0;
    }


}
